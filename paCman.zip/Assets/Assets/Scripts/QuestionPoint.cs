﻿using UnityEngine;

public class QuestionPoint : Point
{
    private void Start() {
        FindObjectOfType<GameManager>().AddQuestion(this);
    }
    protected override void Add()
    {
        FindObjectOfType<GameManager>().QuestionPoint(this);
    }
}
