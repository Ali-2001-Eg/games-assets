using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class Point : MonoBehaviour
{
    public int points = 10;

    protected virtual void Add()
    {
        FindObjectOfType<GameManager>().EatThePoint(this);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            Add();
        }
    }

}
