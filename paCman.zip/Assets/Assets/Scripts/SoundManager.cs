using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum SoundTrigger { GameOver , EatPoint , EatGhost , Die }
public class SoundManager : MonoBehaviour
{
    [SerializeField] private AudioClip gameoverSound;
    [SerializeField] private AudioClip eatPointSound;
    [SerializeField] private AudioClip eatGhostSound;
    [SerializeField] private AudioClip dieSound;

    public static SoundManager Instance { get; private set; }

    private void Awake() {
        Instance = this;
    }


    public void PlaySound(SoundTrigger sound , float volume = 1) {
        Vector3 pos = Camera.main.transform.position;
        switch(sound) {
            case SoundTrigger.GameOver:
                AudioSource.PlayClipAtPoint(gameoverSound , pos, volume );
                break;
            case SoundTrigger.EatPoint:
                AudioSource.PlayClipAtPoint( eatPointSound , pos , volume );
                break;
            case SoundTrigger.EatGhost:
                AudioSource.PlayClipAtPoint( eatGhostSound , pos , volume );
                break;
            case SoundTrigger.Die:
                AudioSource.PlayClipAtPoint( dieSound , pos , volume );
                break;
            default:
                break;
        }
    }

}
