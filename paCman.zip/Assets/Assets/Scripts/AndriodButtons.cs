using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AndriodButtons : MonoBehaviour
{
    [SerializeField] private Button UpBtn;
    [SerializeField] private Button DownBtn;
    [SerializeField] private Button LeftBtn;
    [SerializeField] private Button RightBtn;

    [SerializeField] private Movement pacman;

    private void Start() {
        print( "android buttons is active" );

        

    }
    public void Awake() {

        UpBtn.onClick.AddListener( () => {
            pacman.SetDirection( Vector2.up );
            print( "Up" );
        } );

        DownBtn.onClick.AddListener( () => {
            pacman.SetDirection( Vector2.down );
            print( "Down" );
        } );

        LeftBtn.onClick.AddListener( () => {
            pacman.SetDirection( Vector2.left );
            print( "Left" );
        } );

        RightBtn.onClick.AddListener( () => {
            pacman.SetDirection( Vector2.right );
            print( "Right" );
        } );
    }

}
