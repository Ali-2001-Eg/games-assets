using System.Collections.Generic;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    const string SavedHighestScore = "HIGHESTSCORE";


    [Header("Game Menus")]
    public GameObject MainMenu;
    public GameObject PauseMenu;
    public GameObject GameOverMenu;

    public Button StartBtn;

    public TextMeshProUGUI GameOverHighestScore;
    public TextMeshProUGUI GameOverYourScore;

    public Button PlayAgain;
    public Button BackToMenu;
    public Button Pause_Btn;
    public Button Pause_BackToGameBtn;


    [Header("Game Objects & Data")]
    public Ghost[] ghosts;
    public Pacman pacman;
    public Transform pellets;
    public Text scoreText;
    public Text livesText;
    public Text questionText;
    public TextMeshProUGUI HighestScoreText;
    public int ghostMultiplier { get; private set; } = 1;
    public int score { get; private set; }
    public int lives { get; private set; }
    public char[] operators = { '+' , '-' };
    public int maxNumber = 10;
    public int offset = 3;
    public GameObject PointPrefab;
    public Point last;

    public bool CanEatMultiple = true;
    public int GamePointCount = 1;
    public List<Transform> SpawnPointsPositions;
    public List<Point> PointsToEat;

    public GameObject androidbuttons;

    private bool IsQuestionSolved = true;
    private int _currentPoints = 0;
    //private bool IsPaused = false;//
    private int answer = 0;

    public enum GameState { MAINMENU , NEWGAME , PLAYING , PAUSE , GAMEOVER }
    private GameState state;
    private void Awake() {
        StartBtn.onClick.AddListener( () => {
            SetNewGameState( GameState.NEWGAME );
        } );
        PlayAgain.onClick.AddListener( () => {
            SetNewGameState( GameState.NEWGAME );
        } );
        BackToMenu.onClick.AddListener( () => {
            SetNewGameState( GameState.MAINMENU );
        } );
        Pause_BackToGameBtn.onClick.AddListener( () => {
            SetNewGameState( GameState.PLAYING );
        } );
        Pause_Btn.onClick.AddListener( () => {
            SetNewGameState( GameState.PAUSE );
        } );

    }
    private void Start() {
        MainMenu.SetActive(false);
        PauseMenu.SetActive(false);
        GameOverMenu.SetActive( false );

        SetNewGameState( GameState.MAINMENU );
    }
    private void Update() {

        switch(state) {
            case GameState.MAINMENU:

                break;
            case GameState.NEWGAME:
                
                break;
            case GameState.PLAYING:

                break;
            case GameState.PAUSE:

                break;
            case GameState.GAMEOVER:

                break;
            default:
                break;
        }

        // Show Android Buttons
        if(Screen.fullScreen) {
            androidbuttons.gameObject.SetActive( true );
        }
        else {
            androidbuttons.gameObject.SetActive( false );
        }

        /*if(Input.GetKeyDown( KeyCode.Escape )) {
            IsPaused = !IsPaused;
            if(IsPaused) {
                SetNewGameState( GameState.PAUSE );
            }
            else {
                SetNewGameState( GameState.PLAYING );
            }
        }*/


    }

    public void SetNewGameState(GameState gameState) {
        if(state == GameState.GAMEOVER && gameState == GameState.PAUSE) {
           // IsPaused = false;
            return;
        }
        CloseState( state );

        Startstate( gameState );
    }

    private void Startstate(GameState gameState) {
        switch(gameState) {
            case GameState.MAINMENU:
                Time.timeScale = 0;
                MainMenu.gameObject.SetActive ( true );
                break;
            case GameState.NEWGAME:
                NewGame();
                Time.timeScale = 1;
                state = GameState.PLAYING;
                break;
            case GameState.PLAYING:
                Time.timeScale = 1;
                break;
            case GameState.PAUSE:
                Time.timeScale = 0;
                PauseMenu.gameObject.SetActive( true );
                break;
            case GameState.GAMEOVER:

                GameOverMenu.gameObject.SetActive( true );
                int highscore = PlayerPrefs.GetInt( SavedHighestScore , 0 );

                if(score > highscore) {
                    PlayerPrefs.SetInt( SavedHighestScore , score );
                    PlayerPrefs.Save();
                }
                GameOverHighestScore.text = PlayerPrefs.GetInt( SavedHighestScore ).ToString();
                GameOverYourScore.text = score.ToString();

                break;
            default:
                break;
        }
        state = gameState;
    }

    private void CloseState(GameState gameState) {
        switch(gameState) {
            case GameState.MAINMENU:
                MainMenu.gameObject.SetActive( false );
                break;
            case GameState.NEWGAME:

                break;
            case GameState.PLAYING:
                Time.timeScale = 0;
                break;
            case GameState.PAUSE:
                PauseMenu.gameObject.SetActive( false );
                break;
            case GameState.GAMEOVER:
                GameOverMenu.gameObject.SetActive(false);
                break;
            default:
                break;
        }
    }

    private void NewGame() {
        SetScore( 0 );
        SetLives( 3 );
        NewRound(true);
        CreateNewPoint();
    }

    private void CreateNewPoint() {
        for(; _currentPoints < GamePointCount ; _currentPoints++) {
            // spawn new point in random spot
            // get random position check if it doesn't has a point 
            // instantiate the point and add it to the list
            var spot = GetEmptySpot();
            if(spot != null) {
                Instantiate( PointPrefab , spot );
                continue;
            }
            // if there is no spot 
        }
    }


    private Transform GetEmptySpot() {
        foreach(Transform item in SpawnPointsPositions) {
            if(item.childCount == 0) {
                return item;
            }
        }
        return null;
    }

    private void NewRound(bool ghoastrestposition = false) {
        ghostMultiplier = 1;
        //gameOverText.enabled = false;
        foreach(Transform pellet in pellets) {
            pellet.gameObject.SetActive( true );
        }
        ResetState( ghoastrestposition );
    }

    private void ResetState(bool ghoastrestposition) {
        IsQuestionSolved = true;
        for(int i = 0 ; i < ghosts.Length ; i++) {
            ghosts[i].ResetState( ghoastrestposition );
        }
        pacman.ResetState();
    }

    private void GameOver() {
        //gameOverText.enabled = true;

        /*for (int i = 0; i < ghosts.Length; i++) {
            ghosts[i].gameObject.SetActive(false);
        }*/
        SetNewGameState( GameState.GAMEOVER );
        SoundManager.Instance.PlaySound(SoundTrigger.GameOver);
        pacman.gameObject.SetActive( false );
    }

    private void SetLives(int lives) {
        this.lives = lives;
        livesText.text = "x" + lives.ToString();
    }

    private void SetScore(int score) {
        this.score = score;

        int highscore = PlayerPrefs.GetInt( SavedHighestScore );
        if(score > highscore) {
            PlayerPrefs.SetInt( SavedHighestScore , score );
        }

        HighestScoreText.text = "Highest Score : " + PlayerPrefs.GetInt(SavedHighestScore);
        scoreText.text = "Score : " + score.ToString().PadLeft( 2 , '0' );
    }

    public async void PacmanEaten() {
        questionText.text = "Eat big point to get new question.";
        pacman.DeathSequence();

        if(last)
            last.gameObject.SetActive( true );

        SetLives( lives - 1 );
        SoundManager.Instance.PlaySound( SoundTrigger.Die , 0.8f);
        if(lives > 0) {
            await Task.Delay( 1000 );
            ResetState(false);
        }
        else {
            GameOver();
        }
    }

    public void GhostEaten(Ghost ghost) {
        last = null;
        int points = answer;
        SetScore( score + points );
        foreach(Ghost element in ghosts) {
            if(element == ghost) {
                element.Dead();
            }
            else {
                element.End();
            }
        }
        ghost.isEatable = false;

        IsQuestionSolved = true;
        //if (ghostMultiplier == 5) Invoke(nameof(NewRound), 0.75f);
        questionText.text = ( "Eat big point to get new question." );
        SoundManager.Instance.PlaySound( SoundTrigger.EatGhost );
    }

    public void EatThePoint(Point point) {
        SoundManager.Instance.PlaySound( SoundTrigger.EatPoint , 0.5f);
        SetScore( score + point.points );
        PointsToEat.Remove( point );
        _currentPoints--;
        CreateNewPoint();
        Destroy( point.gameObject );
    }

    private void ResetGhostMultiplier() {
        ghostMultiplier = 1;
    }

    public void QuestionPoint(Point point) {
        if(CanEatMultiple) {
            last = point;
            EatThePoint( point );
            //questionPoint = true;
            newQuestion();
        }else if(!IsQuestionSolved) {
            last = point;
            EatThePoint( point );
            IsQuestionSolved = false;
            newQuestion();
        }
    }
    public int newAnswer(int firstNum , int secondNum , char Operator) {
        switch(Operator) {
            case '+':
                return firstNum + secondNum;
            case '-':
                return firstNum - secondNum;
            case '*':
                return firstNum * secondNum;
            case '/':
                return firstNum / secondNum;
            default:
                return 0;
        }
    }
    public void newQuestion() {
        char Operator = operators[Random.Range( 0 , operators.Length )];
        int firstNum, secondNum;
        if(Operator == '-') {
            firstNum = Random.Range( 0 , maxNumber + 1 );
            secondNum = Random.Range( 0 , firstNum + 1 );
        }
        else if(Operator == '/') {
            secondNum = Random.Range( 1 , maxNumber + 1 );
            firstNum = secondNum * Random.Range( 1 , ( maxNumber / secondNum ) + 1 );
        }
        else {
            firstNum = Random.Range( 0 , maxNumber + 1 );
            secondNum = Random.Range( 0 , maxNumber + 1 );
        }
        answer = newAnswer( firstNum , secondNum , Operator );
        questionText.text = firstNum + " " + Operator + " " + secondNum + " = ?";
        GiveAnswerToGhosts( answer );
    }
    private void GiveAnswerToGhosts(int answer) {
        bool isAnswer = false;
        List<int> values = new List<int>();


        for(int i = 0 ; i < ghosts.Length ; i++) {
            ghosts[i].QuestionPoint();
            int number = Random.Range( answer - offset , answer + offset + 1 );
            if(!values.Contains( number ) && number >= 0) {
                ghosts[i].value.text = number.ToString();
                values.Add( number );
                if(number == answer) {
                    isAnswer = true;
                    ghosts[i].isEatable = true;
                }
            }
            else {
                i--;
            }
        }

        if(!isAnswer) {
            int index = Random.Range( 0 , ghosts.Length );
            values[index] = answer;
            ghosts[index].value.text = answer.ToString();
            ghosts[index].isEatable = true;
        }
    }

    public void AddQuestion(Point question) {
        PointsToEat.Add( question );
    }




}
