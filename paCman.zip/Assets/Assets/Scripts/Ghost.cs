using TMPro;
using UnityEngine;
using UnityEngine.UIElements;

[RequireComponent(typeof(Movement))]
public class Ghost : MonoBehaviour
{
    public Vector3 initialPosition;
    public Movement movement { get; private set; }
    public GhostScatter scatter { get; private set; }
    public GhostChase chase { get; private set; }
    public GhostBehavior initialBehavior;
    public Transform target;
    public int points = 200;
    public SpriteRenderer body;
    public SpriteRenderer eyes;
    public TextMeshPro value;
    public bool isEatable=false;

    private void Awake()
    {
        movement = GetComponent<Movement>();
        scatter = GetComponent<GhostScatter>();
        chase = GetComponent<GhostChase>();
    }

    private void Start()
    {
        ResetState();
    }

    public void ResetState(bool ResetPosition = true)
    {
        isEatable= false;
        gameObject.SetActive(true);
        if(ResetPosition)
            movement.ResetState();
        chase.Disable();
        scatter.Enable();
        End();
    }

    public void SetPosition(Vector3 position)
    {
        // Keep the z-position the same since it determines draw depth
        position.z = transform.position.z;
        transform.position = position;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Pacman"))
        {
            if (isEatable) {
                FindObjectOfType<GameManager>().GhostEaten(this);
            } else {
                FindObjectOfType<GameManager>().PacmanEaten();
            }
        }
    }

    public void QuestionPoint()
    {
        movement.speedMultiplier = 0.5f;
        body.enabled = true;
        eyes.enabled = false;
        value.enabled = true;
    }

    public void End()
    {
        gameObject.SetActive(true);
        body.enabled = true;
        eyes.enabled = true;
        value.enabled = false;
        movement.speedMultiplier = 1f;
    }

    public void Dead()
    {
        movement.SetDirection(new Vector2(1, 0));
        gameObject.SetActive(false);
        transform.position = initialPosition;
        print("Ghost is dead");
        Invoke(nameof(End), 0.8f);
    }
}
